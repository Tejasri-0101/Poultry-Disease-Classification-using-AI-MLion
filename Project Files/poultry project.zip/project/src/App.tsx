import React, { useState } from 'react';
import Navigation from './components/Navigation';
import HomePage from './components/HomePage';
import PredictionPage from './components/PredictionPage';
import SupportPage from './components/SupportPage';

function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [currentPage, setCurrentPage] = useState('home');

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    setCurrentPage(tab);
  };

  const handleGetStarted = () => {
    setCurrentPage('prediction');
    setActiveTab('home'); // Keep home tab active since prediction is part of home flow
  };

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onGetStarted={handleGetStarted} />;
      case 'prediction':
        return <PredictionPage />;
      case 'support':
        return <SupportPage />;
      default:
        return <HomePage onGetStarted={handleGetStarted} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation activeTab={activeTab} onTabChange={handleTabChange} />
      {renderCurrentPage()}
    </div>
  );
}

export default App;