import React from 'react';
import { Mail, Phone, MessageCircle, Book, Users, Globe } from 'lucide-react';

const SupportPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Support Center</h1>
          <p className="text-lg text-gray-600">Get help and support for your poultry health management needs</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {/* Contact Cards */}
          <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-6">
              <Mail className="h-6 w-6 text-blue-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Email Support</h3>
            <p className="text-gray-600 mb-4">Get detailed help via email. We typically respond within 24 hours.</p>
            <a href="mailto:support@poultrypredict.com" className="text-blue-600 hover:text-blue-700 font-medium">
              support@poultrypredict.com
            </a>
          </div>

          <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300">
            <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center mb-6">
              <Phone className="h-6 w-6 text-emerald-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Phone Support</h3>
            <p className="text-gray-600 mb-4">Speak directly with our experts. Available Monday-Friday, 9AM-5PM.</p>
            <a href="tel:+1234567890" className="text-emerald-600 hover:text-emerald-700 font-medium">
              +1 (234) 567-8900
            </a>
          </div>

          <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-6">
              <MessageCircle className="h-6 w-6 text-purple-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Live Chat</h3>
            <p className="text-gray-600 mb-4">Get instant help through our live chat system.</p>
            <button className="text-purple-600 hover:text-purple-700 font-medium">
              Start Chat
            </button>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="bg-white rounded-2xl shadow-xl p-8 mb-8">
          <h2 className="text-2xl font-semibold text-gray-900 mb-8 flex items-center">
            <Book className="h-6 w-6 mr-2 text-emerald-600" />
            Frequently Asked Questions
          </h2>
          
          <div className="space-y-6">
            <div className="border-b border-gray-200 pb-6">
              <h3 className="text-lg font-medium text-gray-900 mb-2">How accurate is the disease prediction?</h3>
              <p className="text-gray-600">Our AI model has been trained on thousands of poultry health images and achieves high accuracy rates. However, results should always be confirmed by a veterinary professional.</p>
            </div>
            
            <div className="border-b border-gray-200 pb-6">
              <h3 className="text-lg font-medium text-gray-900 mb-2">What image formats are supported?</h3>
              <p className="text-gray-600">We support all common image formats including JPG, PNG, BMP, and TIFF. For best results, use high-quality, well-lit images.</p>
            </div>
            
            <div className="border-b border-gray-200 pb-6">
              <h3 className="text-lg font-medium text-gray-900 mb-2">Is my data secure?</h3>
              <p className="text-gray-600">Yes, we take data security seriously. All uploaded images are processed securely and are not stored on our servers after analysis.</p>
            </div>
            
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">Can I use this for commercial purposes?</h3>
              <p className="text-gray-600">Yes, our platform is designed for both individual farmers and commercial poultry operations. Contact us for enterprise solutions.</p>
            </div>
          </div>
        </div>

        {/* Additional Resources */}
        <div className="grid md:grid-cols-2 gap-8">
          <div className="bg-white p-8 rounded-2xl shadow-lg">
            <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-6">
              <Users className="h-6 w-6 text-orange-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Community Forum</h3>
            <p className="text-gray-600 mb-4">Connect with other poultry farmers and share experiences.</p>
            <button className="text-orange-600 hover:text-orange-700 font-medium">
              Join Community
            </button>
          </div>

          <div className="bg-white p-8 rounded-2xl shadow-lg">
            <div className="w-12 h-12 bg-teal-100 rounded-lg flex items-center justify-center mb-6">
              <Globe className="h-6 w-6 text-teal-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Knowledge Base</h3>
            <p className="text-gray-600 mb-4">Browse our comprehensive guides and tutorials.</p>
            <button className="text-teal-600 hover:text-teal-700 font-medium">
              Browse Articles
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SupportPage;