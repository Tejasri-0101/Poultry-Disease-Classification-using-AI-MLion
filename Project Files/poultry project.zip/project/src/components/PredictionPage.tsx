import React, { useState } from 'react';
import { Upload, FileImage, AlertCircle, CheckCircle, Brain } from 'lucide-react';

const PredictionPage: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [prediction, setPrediction] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [dragActive, setDragActive] = useState(false);

  const diseases = [
    { name: 'Colibacillosis', color: 'bg-red-100 text-red-800', icon: '🦠' },
    { name: 'Newcastle', color: 'bg-orange-100 text-orange-800', icon: '⚠️' },
    { name: 'Salmonellosis', color: 'bg-yellow-100 text-yellow-800', icon: '🔬' },
    { name: 'Fowl Cholera', color: 'bg-purple-100 text-purple-800', icon: '🦃' }
  ];

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      setPrediction(null);
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setSelectedFile(e.dataTransfer.files[0]);
      setPrediction(null);
    }
  };

  const handlePredict = async () => {
    if (!selectedFile) return;
    
    setIsLoading(true);
    
    // Simulate AI processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Mock prediction - randomly select one of the diseases
    const randomDisease = diseases[Math.floor(Math.random() * diseases.length)];
    setPrediction(randomDisease.name);
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-emerald-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Disease Prediction</h1>
          <p className="text-lg text-gray-600">Upload an image of your poultry for AI-powered disease analysis</p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8 mb-8">
          {/* File Upload Section */}
          <div className="mb-8">
            <h2 className="text-2xl font-semibold text-gray-900 mb-6 flex items-center">
              <FileImage className="h-6 w-6 mr-2 text-emerald-600" />
              Upload Image
            </h2>
            
            <div
              className={`relative border-2 border-dashed rounded-xl p-8 text-center transition-colors duration-200 ${
                dragActive
                  ? 'border-emerald-400 bg-emerald-50'
                  : selectedFile
                  ? 'border-emerald-300 bg-emerald-25'
                  : 'border-gray-300 hover:border-emerald-400 hover:bg-emerald-25'
              }`}
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
            >
              <input
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
              
              {selectedFile ? (
                <div className="space-y-3">
                  <CheckCircle className="h-12 w-12 text-emerald-600 mx-auto" />
                  <p className="text-lg font-medium text-emerald-700">{selectedFile.name}</p>
                  <p className="text-sm text-gray-500">File selected. Click predict to analyze.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  <Upload className="h-12 w-12 text-gray-400 mx-auto" />
                  <p className="text-lg font-medium text-gray-700">Drop your image here or click to browse</p>
                  <p className="text-sm text-gray-500">Supports JPG, PNG, and other image formats</p>
                </div>
              )}
            </div>
          </div>

          {/* Predict Button */}
          <div className="text-center mb-8">
            <button
              onClick={handlePredict}
              disabled={!selectedFile || isLoading}
              className={`inline-flex items-center space-x-3 px-8 py-4 rounded-xl text-lg font-semibold transition-all duration-200 ${
                !selectedFile || isLoading
                  ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  : 'bg-gradient-to-r from-emerald-600 to-emerald-700 text-white hover:from-emerald-700 hover:to-emerald-800 transform hover:scale-105 shadow-lg hover:shadow-xl'
              }`}
            >
              {isLoading ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  <span>Analyzing...</span>
                </>
              ) : (
                <>
                  <Brain className="h-5 w-5" />
                  <span>Predict Disease</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Results Section */}
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <h2 className="text-2xl font-semibold text-gray-900 mb-6 flex items-center">
            <AlertCircle className="h-6 w-6 mr-2 text-blue-600" />
            Possible Diseases
          </h2>
          
          <div className="grid md:grid-cols-2 gap-4 mb-8">
            {diseases.map((disease, index) => (
              <div
                key={index}
                className={`p-4 rounded-xl border-2 transition-all duration-200 ${
                  prediction === disease.name
                    ? 'border-emerald-400 bg-emerald-50 shadow-md scale-105'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <span className="text-2xl">{disease.icon}</span>
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${disease.color}`}>
                    {disease.name}
                  </span>
                  {prediction === disease.name && (
                    <CheckCircle className="h-5 w-5 text-emerald-600 ml-auto" />
                  )}
                </div>
              </div>
            ))}
          </div>

          {prediction && (
            <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-6">
              <div className="flex items-center space-x-3 mb-3">
                <CheckCircle className="h-6 w-6 text-emerald-600" />
                <h3 className="text-lg font-semibold text-emerald-800">Prediction Result</h3>
              </div>
              <p className="text-emerald-700">
                Based on the uploaded image analysis, the most likely diagnosis is:{' '}
                <span className="font-bold text-emerald-800">{prediction}</span>
              </p>
              <p className="text-sm text-emerald-600 mt-2">
                Please consult with a veterinary professional for proper diagnosis and treatment.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PredictionPage;